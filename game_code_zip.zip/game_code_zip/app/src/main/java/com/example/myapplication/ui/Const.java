package com.example.myapplication.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Const {
    public final static String BUCKET = "Bucket";

    public final static String BUCKET_GET = "Bucket_get";
    public final static String SECOND_FRAGMENT1 = "Second_fragment1";
    public final static String SECOND_FRAGMENT2 = "Second_fragment2";

    public final static String BUCKET_WITH_WATER = "Bucket_with_water";
    public final static String BUCKET_WITH_get = "Bucket_with_get";
    public final static String WATERROM_IS_WORKED = "WATEROM_is_worked";
    public final static String Vospominanie1 = "VOSPOMINANIE1";
    public final static String Vospominanie2 = "VOSPOMINANIE2";
    public final static String ELECTRO_IS_WORKED = "Electro_is_worked";
    public final static String ELECTRO_IS_WORKED2 = "Electro_is_worked2";
    public final static String Door6 = "DOOR6";
    public final static String BATTARY = "Battary";
    public final static String BATTARY_FULL = "Battary_full";
    public final static String RobotFinded= "RobotFinded";
    public final static String podskazki= "RobotFinded";
    public final static String Door7= "DOOR7";
    public final static String Door8= "DOOR8";

    public final static String RADIOQUEST= "RADIQUEST";
    public final static String ROBOT= "ROBOT";
    public final static String IZYCHITRAION= "IZYCHITRAION";
    public final static String BATTARYIFFULL2= "BAttARYiffull2";
    public final static String BADEND= "BADEND";
    public final static String GOODEND= "GOODEND";
    public final static String TIME= "TIME";
    public final static String GAME= "GAME";
    HashMap<String, String[]> getDeps() {
        HashMap<String, String[]> events = new HashMap<>();
        events.put(WATERROM_IS_WORKED, new String[]{BUCKET});
        events.put(BUCKET_WITH_WATER, new String[]{WATERROM_IS_WORKED});
        events.put(BATTARY_FULL, new String[]{BATTARY,ELECTRO_IS_WORKED});
        events.put(ELECTRO_IS_WORKED, new String[]{BUCKET_WITH_WATER,BATTARY});
        events.put(BATTARY, new String[]{BUCKET_WITH_WATER});
        return events;
    }
}
