package com.example.myapplication.ui;

import android.content.Context;

import androidx.appcompat.app.AlertDialog;

public class ShowDialogueMessage {
    public static void show(Context ctx, String title, String message, String buttonLabel) {
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(ctx);
        dlgAlert.setMessage(message);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton(buttonLabel, (dialog, which) -> {
        });
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
}
