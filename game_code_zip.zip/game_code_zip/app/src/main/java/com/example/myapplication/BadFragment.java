package com.example.myapplication;

import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FragmentBadBinding;
import com.example.myapplication.databinding.FragmentBlankBinding;
import com.example.myapplication.databinding.FragmentFirstBinding;
import com.example.myapplication.databinding.FragmentFourBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;

public class BadFragment extends Fragment {

MediaPlayer fxcg;
    private FragmentBadBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding =FragmentBadBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        fxcg= MediaPlayer.create(getContext(), R.raw.fxcg);
        super.onViewCreated(view, savedInstanceState);
        if(Event.haveEvent(Const.BADEND)){
            binding.text.setText("Вы пытались дойти до города но все ваши попытки оказались безнадежны. В конце концов теперь вы погребенны в окрестностях пустыни");
       fxcg.start();
        }


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}