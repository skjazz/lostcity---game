package com.example.myapplication.ui;

import com.orm.SugarRecord;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;

public class Event extends SugarRecord {
    //    static boolean bucket = false;
    private String event;
    //boolean vospominanie2 = false;

    public Event() {
    }

    public Event(String event) {
        this.event = event;
    }

    public static void saveEvent(String event) {
        if (!haveEvent(event)) {
            long id = new Event(event).save();
            System.out.println(id);
        }
    }

    public static boolean haveEvent(String event) {
        return !Event.find(Event.class, "event = ?", event).isEmpty();
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    private void foo() {
        LocalDateTime x = LocalDateTime.now();
        LocalDateTime y = LocalDateTime.now();
        Duration z = Duration.between(y, x);

        //перевести время в число
        long ts = x.toEpochSecond(ZoneOffset.ofHours(0));
        LocalDateTime r = LocalDateTime.ofEpochSecond(ts, 0, ZoneOffset.ofHours(0));
        //перевести число в время
    }

}