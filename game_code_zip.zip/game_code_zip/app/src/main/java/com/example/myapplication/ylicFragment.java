package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.example.myapplication.databinding.FragmentYlica2Binding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;


public class ylicFragment extends Fragment {


    private FragmentYlica2Binding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentYlica2Binding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {

        if (!Event.haveEvent(Const.WATERROM_IS_WORKED)) {
            ShowDialogueMessage.show(getContext(),
                    "Мысли",
                    "Cейчас мне тут нечего делать.",
                    "Понятно"
            );

        }
        binding.button.setAlpha(0.0F);
        super.onViewCreated(view, savedInstanceState);
        binding.buttonSecond5.setVisibility(View.INVISIBLE);


        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.button.setAlpha(0.15F);


                binding.buttonSecond5.setVisibility(View.VISIBLE);

                Event.saveEvent(Const.Door8);

            }
        });
        binding.buttonSecond5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                NavHostFragment.findNavController(ylicFragment.this)

                        .navigate(R.id.action_ylicFragment_to_podval);

            }
        });

        binding.buttonFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(ylicFragment.this)
                        .navigate(R.id.action_ylicFragment_to_fragment6);

            }
        });
        if (Event.haveEvent(Const.Door8)) {

            binding.button.setAlpha(0.15F);
            binding.buttonSecond5.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}