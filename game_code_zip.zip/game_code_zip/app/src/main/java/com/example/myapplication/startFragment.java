package com.example.myapplication;

import static com.example.myapplication.R.raw.menu;

import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FragmentFirstBinding;
import com.example.myapplication.databinding.FragmentFourBinding;
import com.example.myapplication.databinding.FragmentStartBinding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;

public class startFragment extends Fragment {

    private MediaPlayer menu;
    private FragmentStartBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentStartBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       if(! Event.haveEvent(Const.GAME)){
           binding.button5.setVisibility(View.INVISIBLE);
       }
        menu = MediaPlayer.create(getContext(), R.raw.menu);
        menu.start();


        binding.button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    NavHostFragment.findNavController(startFragment.this)

                            .navigate(R.id.action_startFragment_to_SecondFragment);


            }
        });
        binding.button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(startFragment.this)


                        .navigate(R.id.action_startFragment_to_yverenFragment);



            }
        });


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        menu.stop();
        binding = null;

    }

}