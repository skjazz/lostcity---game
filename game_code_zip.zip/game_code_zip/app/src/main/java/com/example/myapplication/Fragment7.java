package com.example.myapplication;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment7Binding;
import com.example.myapplication.ui.Const;
import com.example.myapplication.ui.Event;
import com.example.myapplication.ui.ShowDialogueMessage;


public class Fragment7 extends Fragment {
MediaPlayer robot;
    int k=0;

        private Fragment7Binding binding;

        @Override
        public View onCreateView(
                LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState

        )
        {

            binding = Fragment7Binding.inflate(inflater, container, false);
            return binding.getRoot();

        }

        public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            robot = MediaPlayer.create(getContext(), R.raw.robot);
            if(!Event.haveEvent(Const.BATTARY_FULL)){
robot.start();
            }
            binding.button10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if (Event.haveEvent(Const.BATTARY_FULL)) {
                        ShowDialogueMessage.show(getContext(),
                                "Робот",
                                "Возьми мою батарею и попробуй заряди ее снова, найди Радиостанцию чтобы передать сигнал в близжайший город.",
                                "Хорошо"

                        );
                        try {
                            Thread.sleep(10);

                        } catch (InterruptedException ea) {

                            ea.printStackTrace();

                        }
                        ShowDialogueMessage.show(getContext(),
                                "Робот",
                                "Они не могли подать сигнал помощи, но успели сделать робота и спрятатся в своих домах, с встроенной солнечной панелью и зарядить его, Чтобы тот смог дойти до южного города и запросить помощь. Этим роботом оказался ты.",
                                "Ясно"

                        );
                        try {
                            Thread.sleep(10);

                        } catch (InterruptedException ea) {

                            ea.printStackTrace();

                        }
                        ShowDialogueMessage.show(getContext(),
                                "Робот",
                                "Роботы заряжались с помощью солнечных панелей. В один день началась очень продолжительная буря которая оставила город на несколько неделей без электричества.",
                                "Ясно"

                        );
                        try {
                            Thread.sleep(10);

                        } catch (InterruptedException ea) {

                            ea.printStackTrace();

                        }
                        ShowDialogueMessage.show(getContext(),
                                "Робот",
                                "Значит забыл... Давай я тебе расскажу что сдесь произошло. Давным давно это место населяли люди, А им помогали роботы. Потом они потратили все природные ресурсы этого места и уехали от cюда, оставив сдесь Роботов.",
                                "Ясно"

                        );
                        try {
                            Thread.sleep(10);

                        } catch (InterruptedException ea) {

                            ea.printStackTrace();

                        }
                        ShowDialogueMessage.show(getContext(),
                                "Робот",
                                "Cпасибо что спас меня. Ты наверное ничего не помнишь, оно и  понятно ведь произошло столько времени,ты ведь пришел с помощью?",
                                "Нет"

                        );
                        Event.saveEvent(Const.ROBOT);
                        Event.saveEvent(Const.RADIOQUEST);
                    } else {
                        k++;
                        if (k < 2) {
                            ShowDialogueMessage.show(getContext(),
                                    "Робот",
                                    "Error: не хватает энергии",
                                    "Понятно"

                            );
                            Event.saveEvent(Const.RobotFinded);
                        } else {


                            ShowDialogueMessage.show(getContext(),
                                    "Подсказка",
                                    "Нужно как то зарядить робота. Может в индустриальной части что то найдется?",
                                    "Понятно"
                            );
                        }
                    }
                }
            });


            ShowDialogueMessage.show(getContext(),
                    "Мысли",
                    "Это робот! он выглядит старым. Нужно его починить.",
                    "Понятно"
            );
            binding.button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    NavHostFragment.findNavController(Fragment7.this)
                            .popBackStack();

                }
            });
            Thread t4 = new Thread(() -> {
                try {
                    Thread.sleep(5000);

                } catch (InterruptedException ea) {

                    ea.printStackTrace();

                }
                binding.button10.setVisibility(View.VISIBLE);
            });



        }

        @Override
        public void onDestroyView() {
            super.onDestroyView();
            binding = null;
        }

    }
